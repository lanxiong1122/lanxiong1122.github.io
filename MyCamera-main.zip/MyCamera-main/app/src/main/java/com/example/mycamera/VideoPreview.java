package com.example.mycamera;




import static com.example.mycamera.FileUtil.currentOutputVideoPath;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoPreview extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actvity_preview);

        VideoView videoView = findViewById(R.id.videoView);

        Log.e("播放链接:",""+currentOutputVideoPath);
        videoView.setVideoURI(Uri.parse(currentOutputVideoPath));

        // 设置视频控制器，允许用户进行播放、暂停等操作
        MediaController mediaController = new MediaController(this);
        videoView.setMediaController(mediaController);
        mediaController.setAnchorView(videoView);

        // 开始播放前的准备
        videoView.requestFocus();
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                // 视频准备完毕后自动开始播放
                videoView.start();
            }
        });

        // 可选：设置播放完成监听器
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                // 视频播放结束时的操作
            }
        });


        findViewById(R.id.re_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}

