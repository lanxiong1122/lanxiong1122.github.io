package com.example.mycamera.util;

import android.text.TextUtils;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import cn.hutool.crypto.digest.DigestUtil;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class HttpRequestUtils {

    //private static final String USER_AGENT = "Apifox/1.0.0 (https://apifox.com)";
    private static final OkHttpClient okHttpClient = new OkHttpClient();
    private static final String BASE_URL = "https://xunishexiangtou.com/app/device";
    //private static final String BASE_URL = "http://38.54.87.224:8080/app/device";
    private static final String PATH_IS_ACTIVE = "/isActive";
    private static final String PATH_TO_ACTIVE = "/toActive";

    public static void postIsActive(String deviceId, HttpRequestCallback callback) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("deviceId", deviceId);
        } catch (Exception e) {
            callback.onError("Failed to create JSON object: " + e.getMessage());
            return;
        }

        RequestBody requestBody = RequestBody.create(
                MediaType.parse("application/json; charset=utf-8"),
                jsonObject.toString()
        );

        Request request = new Request.Builder()
                .url(buildUrlWithQueryParams(PATH_IS_ACTIVE))
                .post(requestBody)
                //.addHeader("User-Agent", USER_AGENT)
                .addHeader("Content-Type", "application/json")
                .build();

        okHttpClient.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                callback.onError(e.getMessage());
            }

            @Override
            public void onResponse(okhttp3.Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    ActivationResponse activationResponse = IsActiveResponse(responseBody);
                    callback.onSuccess(activationResponse);
                } else {
                    callback.onError("Request failed with code: " + response.code());
                }
            }
        });
    }

    public static void toActive(String deviceId, String activeCode, ActivationCallback callback) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("deviceId", deviceId);
            jsonObject.put("activeCode", activeCode);
            SortedMap<Object,Object> parameters = new TreeMap<Object,Object>();
            parameters.put("deviceId", deviceId);
            parameters.put("activeCode", activeCode);
            jsonObject.put("signature", createSign(parameters,"vituralFXXsadfdl12op45"));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        RequestBody requestBody = RequestBody.create(
                MediaType.parse("application/json; charset=utf-8"),
                jsonObject.toString()
        );

        Request request = new Request.Builder()
                .url(buildUrlWithQueryParams(PATH_TO_ACTIVE))
                .post(requestBody)
                //.addHeader("User-Agent", USER_AGENT)
                .addHeader("Content-Type", "application/json")
                .build();

        okHttpClient.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                callback.onError(e.getMessage());
            }

            @Override
            public void onResponse(okhttp3.Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    ActivationResponse activationResponse = parseResponse(responseBody);
                    callback.onSuccess(activationResponse);
                } else {
                    callback.onError("Request failed with code: " + response.code());
                }
            }
        });
    }

    private static ActivationResponse parseResponse(String responseBody) {
        ActivationResponse activationResponse = new ActivationResponse();
        try {
            JSONObject jsonObject = new JSONObject(responseBody);
            activationResponse.setStatusCode(jsonObject.getInt("status_code"));
            activationResponse.setMessage(jsonObject.getString("message"));
        } catch (Exception e) {
            // Handle parsing errors
            e.printStackTrace();
        }
        return activationResponse;
    }
    private static ActivationResponse IsActiveResponse(String responseBody) {
        ActivationResponse activationResponse = new ActivationResponse();
        try {
            JSONObject jsonObject = new JSONObject(responseBody);
            activationResponse.setHomeUrl(jsonObject.getString("homeUrl"));
            activationResponse.setExpired(jsonObject.getString("expired"));
            activationResponse.setActive(jsonObject.getBoolean("isActive"));
        } catch (Exception e) {
            // Handle parsing errors
            e.printStackTrace();
        }
        return activationResponse;
    }
    public interface HttpRequestCallback {
        void onSuccess(ActivationResponse result);
        void onError(String error);
    }

    public interface ActivationCallback {
        void onSuccess(ActivationResponse result);
        void onError(String error);
    }

    private static String buildUrlWithQueryParams(String path, String... params) {
        StringBuilder urlBuilder = new StringBuilder(BASE_URL);
        urlBuilder.append(path);
        boolean firstParam = true;

        if (params.length % 2 != 0) {
            throw new IllegalArgumentException("Invalid number of parameters. Expected even number.");
        }

        for (int i = 0; i < params.length; i += 2) {
            if (!TextUtils.isEmpty(params[i + 1])) {
                if (firstParam) {
                    urlBuilder.append("?");
                    firstParam = false;
                } else {
                    urlBuilder.append("&");
                }
                urlBuilder.append(params[i]).append("=").append(params[i + 1]);
            }
        }

        return urlBuilder.toString();
    }
    public static String createSign(SortedMap<Object,Object> parameters, String key){
        StringBuffer sb = new StringBuffer();
        StringBuffer sbkey = new StringBuffer();
        Set es = parameters.entrySet();  //所有参与传参的参数按照accsii排序（升序）
        Iterator it = es.iterator();
        while(it.hasNext()) {
            Map.Entry entry = (Map.Entry)it.next();
            String k = (String)entry.getKey();
            Object v = entry.getValue();
            //空值不传递，不参与签名组串
            if(null != v && !"".equals(v)) {
                sb.append(k + "=" + v + "&");
                sbkey.append(k + "=" + v + "&");
            }
        }
        //Log.e("println","字符串:"+sb.toString());
        sbkey.deleteCharAt(sb.length() - 1);
        sbkey=sbkey.append(key);
        Log.e("println","字符串:"+sbkey.toString());
        //MD5加密
        String sign = DigestUtil.md5Hex(sbkey.toString());
        Log.e("println","MD5加密值:"+sign);
        return sign;
    }
}