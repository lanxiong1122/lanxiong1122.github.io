package com.example.mycamera;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

public class FileUtil {

    private static final String TAG = "FileUtil";
    public static String currentOutputVideoPath = "";  //压缩后的视频地址


    // 写入文件
    public static void copyVideoToDestination(Activity mContext, Uri srcUri, String destPath) {
        try {
            InputStream in = mContext.getContentResolver().openInputStream(srcUri);
            if (in == null) {
                mContext.runOnUiThread(() -> Toast.makeText(mContext, "无法打开源文件", Toast.LENGTH_SHORT).show());
                return;
            }

            File destFile = new File(destPath);
            // 检查目标文件是否存在，存在则删除
            if (destFile.exists()) {
                boolean deleted = destFile.delete();
                if (!deleted) {
                    Log.e("TAG", "Failed to delete the existing file.");
                }
            }
            // 确保目标文件的父目录存在
            if (!destFile.getParentFile().exists()) {
                destFile.getParentFile().mkdirs(); // 创建缺失的目录结构
            }
            if (!destFile.getParentFile().exists()) {
                destFile.getParentFile().mkdirs(); // 确保目标目录存在
            }

            OutputStream out = new FileOutputStream(destFile);

            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            in.close();
            out.flush();
            out.close();
            mContext.runOnUiThread(() ->Toast.makeText(mContext, "选择视频成功", Toast.LENGTH_SHORT).show());
        } catch (Exception e) {
            e.printStackTrace();
            mContext.runOnUiThread(() ->Toast.makeText(mContext, "选择视频失败", Toast.LENGTH_SHORT).show());
        }
    }


    // 确保文件及其父目录存在
    private static void ensureFileAndDirs(File file) throws Exception {
        if (file.exists()) {
            if (!file.delete()) {
                throw new Exception("Failed to delete the existing file.");
            }
        }
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
    }

    // 获取真实路径
    public static String getRealPathFromUri(Context context, Uri uri) {
        String filePath = null;

        if (uri == null) {
            return filePath;
        }

        // 判断是否是Content Uri
        if (ContentResolver.SCHEME_CONTENT.equals(uri.getScheme())) {
            // 1. MediaStore Uri
            if (isMediaDocument(uri)) {
                filePath = getMediaDocumentPath(context, uri);
            }
            // 2. Downloads Document
            else if (isDownloadsDocument(uri)) {
                filePath = getDownloadsDocumentPath(context, uri);
            }
            // 3. External Storage Document
            else if (isExternalStorageDocument(uri)) {
                filePath = getExternalStorageDocumentPath(uri);
            }
            // 可能需要处理更多类型的Content Provider Uri
            // ...
        }
        // 如果是文件系统的Uri，则直接获取路径
        else if (ContentResolver.SCHEME_FILE.equals(uri.getScheme())) {
            filePath = uri.getPath();
        }

        return filePath;
    }

    private static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    private static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    private static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    private static String getMediaDocumentPath(Context context, Uri uri) {
        String docId = DocumentsContract.getDocumentId(uri);
        String[] split = docId.split(":");
        String type = split[0];

        Uri contentUri = null;
        if ("image".equals(type)) {
            contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        } else if ("video".equals(type)) {
            contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        } else if ("audio".equals(type)) {
            contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        }

        String selection = "_id=?";
        String[] selectionArgs = new String[]{split[1]};
        return queryFilePath(context, contentUri, selection, selectionArgs);
    }

    private static String getDownloadsDocumentPath(Context context, Uri uri) {
        String id = DocumentsContract.getDocumentId(uri);
        if (id.startsWith("raw:")) {
            return id.replaceFirst("raw:", "");
        }

        String[] contentUriPrefixesToTry = new String[]{
                "content://downloads/public_downloads",
                "content://downloads/my_downloads",
        };

        for (String contentUriPrefix : contentUriPrefixesToTry) {
            try {
                Uri contentUri = ContentUris.withAppendedId(Uri.parse(contentUriPrefix), Long.valueOf(id));
                String path = queryFilePath(context, contentUri, null, null);
                if (path != null) {
                    return path;
                }
            }catch (Exception e){
                e.printStackTrace();
            }

        }
        return null;
    }

    private static String getExternalStorageDocumentPath(Uri uri) {
        String docId = DocumentsContract.getDocumentId(uri);
        String[] split = docId.split(":");
        if (split.length >= 2) {
            String type = split[0];
            if ("primary".equalsIgnoreCase(type)) {
                return Environment.getExternalStorageDirectory() + "/" + TextUtils.join("/", Arrays.asList(split).subList(1, split.length));
            }
        }
        return null;
    }
    private static String queryFilePath(Context context, Uri uri, String selection, String[] selectionArgs) {
        Cursor cursor = context.getContentResolver().query(uri, null, selection, selectionArgs, null);
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(MediaStore.MediaColumns.DATA);
                    if (index != -1) {
                        return cursor.getString(index);
                    }
                }
            } finally {
                cursor.close();
            }
        }
        return null;
    }

    // 创建文件
    public static void createMyFile(File lookFile) {
        // 检查文件是否存在
        if (!lookFile.exists()) {
            try {
                // 文件不存在，尝试创建文件
                boolean isCreated = lookFile.createNewFile();
                if (isCreated) {
                    Log.d("FileOperation", "文件创建成功:"+lookFile.getPath());
                } else {
                    Log.d("FileOperation", "文件创建失败");
                }
            } catch (IOException e) {
                e.printStackTrace();
                Log.e("FileOperation", "创建文件时发生错误: " + e.getMessage());
            }
        } else {
            Log.d("FileOperation", "文件已存在:"+lookFile.getPath());
        }
    }
}
