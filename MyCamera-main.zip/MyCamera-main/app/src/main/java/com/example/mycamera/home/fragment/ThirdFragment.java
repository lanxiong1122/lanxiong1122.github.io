package com.example.mycamera.home.fragment;

import static android.app.Activity.RESULT_OK;

import static com.example.mycamera.FileUtil.createMyFile;
import static com.example.mycamera.FileUtil.currentOutputVideoPath;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.example.mycamera.FileUtil;
import com.example.mycamera.MainActivity;
import com.example.mycamera.R;
import com.example.mycamera.VideoPreview;
import com.example.mycamera.dealvideo.CompressListener;
import com.example.mycamera.dealvideo.Compressor;
import com.example.mycamera.dealvideo.CustomProgressDialog;
import com.example.mycamera.dealvideo.GetPathFromUri;
import com.example.mycamera.dealvideo.InitListener;
import com.example.mycamera.home.HomeActivity;
import com.example.mycamera.util.ActivationResponse;
import com.example.mycamera.util.CameraHelper;
import com.example.mycamera.util.HttpRequestUtils;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitmapUtils;
import com.snail.antifake.deviceid.androidid.IAndroidIdUtil;
import com.snail.antifake.deviceid.deviceid.DeviceIdUtil;

import org.w3c.dom.Text;

import java.io.File;
import java.io.IOException;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ThirdFragment extends Fragment {

    private String TAG = this.getClass().getName();
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private View mThirdView;
    private ImageView mImage;
    private TextView showDeviceId;
    private TextView selectVideo,showPreLog;
    private SurfaceView mSurfaceView3;
    private CameraHelper mCameraHelper3;             // 替换以及还原
    private int PICK_VIDEO_REQUEST = 10086;      //选择视频
    private Spinner spin_corner;                 //角度
    private Spinner spin_resolution;             //分辨率
    private String videoCorner;                  //视频角度
    private String videoResolution;              //视频分辨率
    private String mVideoPath = "";              //原视频地址

    private Compressor mCompressor;
    private String videoTime = "";               //获取视频时长
    private int videoWidth = 0;                  //获取视频的宽度
    private int videoHeight = 0;                 //获取视频的高度
    private int videoDirection = 0;               //获取视频的角度
    private Double videoLength = 0.00;           //视频时长 s
    private CustomProgressDialog mProcessingDialog;

    private TextView cameraStatus;
    FrameLayout frameLayout;
    VideoView videoView;
    EditText activeCode;
    TextView activeDate;
    Button activeButton;

    public ThirdFragment() {
        // Required empty public constructor
    }

    public static ThirdFragment newInstance(String param1, String param2) {
        ThirdFragment fragment = new ThirdFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (mThirdView == null){
            mThirdView = inflater.inflate(R.layout.fragment_third, container, false);
        }
        initThird();
        return mThirdView;
    }

    private void initThird() {

        spin_corner = mThirdView.findViewById(R.id.spin_corner);
        spin_resolution = mThirdView.findViewById(R.id.spin_resolution);
        showPreLog = mThirdView.findViewById(R.id.showPreLog);
        cameraStatus = mThirdView.findViewById(R.id.camera_status);
        activeCode = mThirdView.findViewById(R.id.type_active);
        activeDate = mThirdView.findViewById(R.id.device_status);
        activeButton = mThirdView.findViewById(R.id.togoActivity);

        sync_statue_with_files();
        // 播放路径
        currentOutputVideoPath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/DCIM/Camera1/virtual.mp4";
        // 压缩处理路径
        //SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        //mVideoPath = sharedPreferences.getString("filePathKey", "");
        // 展示二维码
        mImage = mThirdView.findViewById(R.id.show_deviceId_qrcode);
        showDeviceId = mThirdView.findViewById(R.id.show_deviceId);
        showDeviceId.setText("设备id:"+ IAndroidIdUtil.getAndroidId(getContext()));
        String content = ""+IAndroidIdUtil.getAndroidId(getContext());
        Bitmap bitmap = null;
        try {
            bitmap = BitmapUtils.create2DCode(content);
            mImage.setImageBitmap(bitmap);
        } catch (WriterException e) {
            e.printStackTrace();
        }
        // 激活时间
        RefreshDate();
        // 激活
        activeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (activeCode.getText().toString().isEmpty()){
                    Toast.makeText(getContext(), R.string.type_active_code, Toast.LENGTH_SHORT).show();
                    return;
                }
                toGo("-----");
            }
        });

        // 替换
        mThirdView.findViewById(R.id.tihuan_cameara).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!canActive){ // 未激活
                    setCamearaStatus(true);
                    Toast.makeText(getContext(), R.string.active, Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(getActivity(), "已替换", Toast.LENGTH_SHORT).show();
                setCamearaStatus(false);
                // 为了预览视频不可见,重置
                frameLayout.setVisibility(View.VISIBLE);
                if (mCameraHelper3 != null){
                    mCameraHelper3.onDestroy();
                    mCameraHelper3 = null;
                }
                frameLayout.removeAllViews();
                videoView.setVisibility(View.GONE);
            }
        });
        //还原
        mThirdView.findViewById(R.id.huanyuan_camera).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "已还原", Toast.LENGTH_SHORT).show();
                setCamearaStatus(true);
                // 为了预览视频不可见,重置
                frameLayout.setVisibility(View.VISIBLE);
                if (mCameraHelper3 != null){
                    mCameraHelper3.onDestroy();
                    mCameraHelper3 = null;
                }
                frameLayout.removeAllViews();
                videoView.setVisibility(View.GONE);
            }
        });


        // 选择视频
        selectVideo = mThirdView.findViewById(R.id.step_two_content_two);
        selectVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("video/*"); // 设置类型为视频
                startActivityForResult(intent, PICK_VIDEO_REQUEST);
            }
        });

        // 旋转角度
        ArrayAdapter<CharSequence> adapterCorner = ArrayAdapter.createFromResource(getContext(), R.array.corner, android.R.layout.simple_spinner_item);
        adapterCorner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_corner.setAdapter(adapterCorner);
        spin_corner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                videoCorner = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // 不做处理
            }
        });
        // 选择分辨率
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.resolution, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_resolution.setAdapter(adapter);
        spin_resolution.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                videoResolution = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // 不做处理
            }
        });
        
        //  预览
        frameLayout = mThirdView.findViewById(R.id.yulan_view);
        videoView = mThirdView.findViewById(R.id.videoViewThree);
        if ("相机未替换".equals(cameraStatus.getText().toString())){
            frameLayout.setVisibility(View.VISIBLE);
            videoView.setVisibility(View.GONE);
        }else {
            frameLayout.setVisibility(View.GONE);
            videoView.setVisibility(View.VISIBLE);
        }
        mThirdView.findViewById(R.id.third_preview).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getActivity().checkSelfPermission(Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, 100);
                    return;
                }
                try{
                    if ("相机未替换".equals(cameraStatus.getText().toString())){
                        initHuanyuanVideo();
                    }else {
                        startCompress();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        mThirdView.findViewById(R.id.third_preview).setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                startActivity(new Intent(getActivity(), VideoPreview.class));
                return true;
            }
        });
        // 停止
        mThirdView.findViewById(R.id.third_stop).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchToward();
            }
        });
        initCompressVideo();
    }

    // true还原  false替换
    private void setCamearaStatus(boolean b){
        //Toast.makeText(getActivity(), b?"还原":"替换", Toast.LENGTH_SHORT).show();
            if (!has_permission()) {
                request_permission();
            } else {
                File disable_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/disable.jpg");
                if (disable_file.exists() != b){
                    if (b){
                        try {
                            disable_file.createNewFile();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }else {
                        disable_file.delete();
                    }
                }
            }
            sync_statue_with_files();
    }
    @Override
    public void onResume() {
        super.onResume();
        //toGo(mVideoPath);
        sync_statue_with_files();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            // 将其写入预览视频，后面修改角度及分辨率等会进行替换
            new Thread(new Runnable() {
                @Override
                public void run() {
                    FileUtil.copyVideoToDestination(getActivity(), data.getData(), "/storage/emulated/0/DCIM/Camera1/virtual.mp4");
                }
            }).start();
            // 获取真实路径，将其展示出来
            mVideoPath = GetPathFromUri.getPath(getContext(), data.getData());
            Log.i(TAG, "Select file: " + mVideoPath);
            selectVideo.setText("" + mVideoPath);
            // 打印视频信息
            getVideoTime(mVideoPath);
            // 把路径存储
            SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("filePathKey", mVideoPath);
            editor.apply();
        }
    }
    private void initCompressVideo() {
        mProcessingDialog = new CustomProgressDialog(getContext());
        mProcessingDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                Log.i(TAG, "onDismiss");//如果取消压缩，那么需要销毁
                if (mCompressor != null) {
                    mCompressor.destory();
                }
            }
        });

        mCompressor = new Compressor(getActivity());
        mCompressor.loadBinary(new InitListener() {
            @Override
            public void onLoadSuccess() {
                Log.v(TAG, "load library succeed");
            }

            @Override
            public void onLoadFail(String reason) {
                Log.i(TAG, "load library fail:" + reason);
            }
        });
    }
    private void switchToward(){
        try {
            if ("相机未替换".equals(cameraStatus.getText().toString())){
                if (mCameraHelper3 != null){
                    mCameraHelper3.onDestroy();
                    mCameraHelper3 = null;
                }
                frameLayout.removeView(mSurfaceView3);
            }else {
                if (videoView != null) {
                    // 停止播放
                    videoView.stopPlayback();
                    // 清除监听器等
                    videoView.setOnPreparedListener(null);
                    videoView.setOnCompletionListener(null);
                    videoView.setOnErrorListener(null);
                    videoView.setOnInfoListener(null);
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    /**
     * 处理视频
     */
    private void startCompress() {
        try {
            if (TextUtils.isEmpty(mVideoPath) || (videoResolution.equals("默认原始分辨率") && videoCorner.equals("默认原始角度"))) {
               Toast.makeText(getActivity(), TextUtils.isEmpty(mVideoPath) ? "如需要处理分辨率和角度，需重新选择视频" : "未选择角度或分辨率不用处理", Toast.LENGTH_SHORT).show();
                initTihuanVideo();
            } else {
                File file = new File(currentOutputVideoPath);
                if (file.exists()) {
                    file.delete();
                }
                String cmd = "";
                Log.i(TAG, "startCompress=mVideoPath=" + mVideoPath);

                if ("默认原始分辨率".equals(videoResolution))
                    videoResolution = videoWidth + "x" + videoHeight;
                Log.e(TAG, "分辨率: " + videoResolution);
                // 根据旋转角度设置transpose滤镜
                String transposeFilter = "";
                switch (videoCorner) {
                    case "顺时针90度":
                        transposeFilter = "transpose=1";
                        break;
                    case "逆时针90度":
                        transposeFilter = "transpose=2";
                        break;
                    default:
                        transposeFilter = "";
                        break;
                }
                Log.e(TAG, "旋转角度: " + videoCorner);
                // 构建FFmpeg命令
                cmd = "-y -i " + mVideoPath + " -strict -2"
                        + (transposeFilter.isEmpty() ? "" : " -vf " + transposeFilter) + " -vcodec libx264 -preset ultrafast "
                        + "-crf 24 -acodec aac -ar 44100 -ac 2 -b:a 96k -s " + videoResolution
                        /*+ (aspectRatioStr.isEmpty() ? "" : " -aspect " + aspectRatioStr)*/   // 视频宽高比，暂时不需要，不设根据原始视频
                        + " " + currentOutputVideoPath;
                // 成功示例，空格问题导致执行不成功
                /*cmd = "-y -i " + mVideoPath + " -strict -2 -vf transpose=3 -vcodec libx264 -preset ultrafast " +
                        "-crf 24 -acodec aac -ar 44100 -ac 2 -b:a 96k -s 1080x1920 -aspect 9:16 " + currentOutputVideoPath;*/
                Log.e(TAG, "Generated FFmpeg command: " + cmd);
                mProcessingDialog.show();
                mProcessingDialog.setProgress(0);
                execCommand(cmd);
            }
        } catch (Exception e) {
            Log.e(TAG, "startCompress=e=" + e.getMessage());
        }
    }
    private void initTihuanVideo(){
        frameLayout.setVisibility(View.GONE);
        videoView.setVisibility(View.VISIBLE);

        Log.e("播放链接:",""+currentOutputVideoPath);
        if (TextUtils.isEmpty(currentOutputVideoPath)){
            Toast.makeText(getActivity(), "替换视频为空，请选择", Toast.LENGTH_SHORT).show();
            return;
        }
        videoView.setVideoURI(Uri.parse(currentOutputVideoPath));

        // 设置视频控制器，允许用户进行播放、暂停等操作
//        MediaController mediaController = new MediaController(getActivity());
//        videoView.setMediaController(mediaController);
//        mediaController.setAnchorView(videoView);

        // 开始播放前的准备
        //videoView.requestFocus();
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                // 视频准备完毕后自动开始播放
                videoView.start();
            }
        });

        // 可选：设置播放完成监听器
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                // 视频播放结束时的操作
            }
        });
    }
    private void initHuanyuanVideo(){
        frameLayout.setVisibility(View.VISIBLE);
        videoView.setVisibility(View.GONE);
        // 每次重启释放
        if (mCameraHelper3 != null){
            return;
        }
        if (mSurfaceView3 == null) mSurfaceView3 = new SurfaceView(getActivity());
        mSurfaceView3.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        if (mSurfaceView3.getParent() != null && mSurfaceView3.getParent() instanceof ViewGroup) {
            ((ViewGroup) mSurfaceView3.getParent()).removeView(mSurfaceView3);
        }
        frameLayout.addView(mSurfaceView3);
        mCameraHelper3 = new CameraHelper(getContext(),mSurfaceView3);
    }
    /**
     * 获取视频的时长
     */
    void getVideoTime(String videoPath) {
        try {
            MediaMetadataRetriever retr = new MediaMetadataRetriever();
            retr.setDataSource(videoPath);
            videoTime = retr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);//获取视频时长
            videoWidth = Integer.parseInt(retr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));//获取视频的宽度
            videoHeight = Integer.parseInt(retr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));//获取视频的高度
            videoDirection = Integer.parseInt(retr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));//获取视频的角度

            Log.e(TAG, "videoTime=" + videoTime);
            Log.e(TAG, "videoWidth=" + videoWidth);
            Log.e(TAG, "videoHeight=" + videoHeight);
            Log.e(TAG, "videoDirection=" + videoDirection);

//            MyLog.i(TAG, "videoTime=" + videoTime);
//            mBitMap = retr.getFrameAtTime();
            videoLength = Double.parseDouble(videoTime) / 1000.00;
            Log.e(TAG, "videoLength=" + videoLength);
            showPreLog.setText("success " +
                    "videoTime=" + videoTime+"毫秒\n" +
                    "videoWidth=" + videoWidth+"\n"+
                    "videoHeight=" + videoHeight+"\n"+
                    "videoDirection=" + videoDirection+"\n"+
                    "videoLength=" + videoLength+"秒\n");
        } catch (Exception e) {
            e.printStackTrace();
            Log.i(TAG, "e=" + e.getMessage());
            videoLength = 0.00;
            Toast.makeText(getActivity(), "异常错误", Toast.LENGTH_SHORT);
        }
    }

    private void request_permission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (getActivity().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
                    || getActivity().checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle(R.string.permission_lack_warn);
                builder.setMessage(R.string.permission_description);

                builder.setNegativeButton(R.string.negative, (dialogInterface, i) -> Toast.makeText(getContext(), R.string.permission_lack_warn, Toast.LENGTH_SHORT).show());

                builder.setPositiveButton(R.string.positive, (dialogInterface, i) -> requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1));
                builder.show();
            }
        }
    }

    private boolean has_permission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return getActivity().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_DENIED
                    && getActivity().checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_DENIED;
        }
        return true;
    }


    private void sync_statue_with_files() {
        try {
            if (!has_permission()){
                request_permission();
            }else {
                File camera_dir = new File (Environment.getExternalStorageDirectory().getAbsolutePath()+"/DCIM/Camera1");
                if (!camera_dir.exists()){
                    camera_dir.mkdir();
                };
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        // 1关闭加载模块功能即还原相机
        File disable_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/disable.jpg");
        //disable_switch.setChecked(disable_file.exists());
        cameraStatus.setText(disable_file.exists()?"相机未替换":"相机已替换");
        cameraStatus.setTextColor(disable_file.exists()?getContext().getColor(R.color.mred):getContext().getColor(R.color.mgreen));

        // 2显示权限缺失应用，例如读写
        File force_show_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/force_show.jpg");
        createMyFile(force_show_file);

        // 3视频有声音
        File play_sound_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/no-silent.jpg");
        createMyFile(play_sound_file);

        // 4强制视频在相机目录下
        File force_private_dir_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/private_dir.jpg");
        createMyFile(force_private_dir_file);

        // 关闭提示消息
        File disable_toast_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/no_toast.jpg");
        //disable_toast_switch.setChecked(disable_toast_file.exists());

        try{
            // 获取SharedPreferences实例
            SharedPreferences sharedPreferences = getActivity().getPreferences(Context.MODE_PRIVATE);
            File showFile = new File("/storage/emulated/0/DCIM/Camera1/virtual.mp4");
            selectVideo.setText("当前选择视频路径："+(showFile.exists() ? sharedPreferences.getString("filePathKey", "空") : "空"));
        }catch (Exception e){
            e.printStackTrace();
        }
    }

        private void execCommand(final String cmd) {
            File mFile = new File(currentOutputVideoPath);
            if (mFile.exists()) {
                mFile.delete();
            }
            Log.i(TAG, "cmd= " + cmd);
            mCompressor.execCommand(cmd, new CompressListener() {
                @Override
                public void onExecSuccess(String message) {
                    mProcessingDialog.dismiss();
                    String result = getString(R.string.compress_result_input_output, mVideoPath
                            , getFileSize(mVideoPath), currentOutputVideoPath, getFileSize(currentOutputVideoPath));
                    Log.i(TAG, "success " + result);
                    getVideoTime(currentOutputVideoPath);
                    //Toast.makeText(MainActivity.this, "success " + result, Toast.LENGTH_SHORT).show();
                    initTihuanVideo();
                }

                @Override
                public void onExecFail(String reason) {
                    Log.i(TAG, "fail " + reason);
                    showPreLog.setText("fail " + reason);
                    //Toast.makeText(MainActivity.this, "压缩失败", Toast.LENGTH_SHORT);
                    mProcessingDialog.dismiss();
                }

                @Override
                public void onExecProgress(String message) {
                    try {
                        Log.i(TAG, "progress " + message);
                        showPreLog.setText("progress " + message);
                        double switchNum = getProgress(message);
                        if (switchNum == 10000) {
                            //如果找不到压缩的片段，返回为10000
                            Log.i(TAG, "10000");
                            mProcessingDialog.setProgress(0);
                        } else {
                            mProcessingDialog.setProgress((int) (getProgress(message) / 10));
                        }
                    } catch (Exception e) {
                        mProcessingDialog.dismiss();
                        Log.i(TAG, "e=" + e.getMessage());
                    }
                }
            });
        }

        // 进度条，只能是整形，所以max为1000，最少为0
        double getProgressNum = 0.0;

        private double getProgress(String source) {
            if (source.contains("too large")) {//当文件过大的时候，会会出现 Past duration x.y too large
                Log.i(TAG, "too large");
                return getProgressNum;
            }
            Pattern p = Pattern.compile("00:\\d{2}:\\d{2}");
            Matcher m = p.matcher(source);
            if (m.find()) {
                //00:00:00
                String result = m.group(0);
                String temp[] = result.split(":");
                double seconds = Double.parseDouble(temp[1]) * 60 + Double.parseDouble(temp[2]);
                if (0 != videoLength) {
                    getProgressNum = seconds / videoLength * 1000;
                    return seconds / videoLength * 1000;
                }
                if (seconds == videoLength) {
                    return 1000;
                }
            }
//        MyLog.i(TAG, "!m.find()="+getProgressNum);
            return 10000;//出现异常的时候，返回为10000
//      return 0;//出现异常的时候，显示上一个进度条
        }

        private String getFileSize(String path) {
            File f = new File(path);
            if (!f.exists()) {
                return "0 MB";
            } else {
                long size = f.length();
                return (size / 1024f) / 1024f + "MB";
            }
        }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mCompressor != null) {
            mCompressor.destory();
        }
        if (videoView != null) {
            // 停止播放
            videoView.stopPlayback();

            // 清除监听器等
            videoView.setOnPreparedListener(null);
            videoView.setOnCompletionListener(null);
            videoView.setOnErrorListener(null);
            videoView.setOnInfoListener(null);
        }
    }

    public  boolean canActive;
    private void toGo(String activeEeCode){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (TextUtils.isEmpty(activeCode.getText().toString())){
                    return;
                }
                /*{statusCode=1001, message='激活码不存在'} statusCode = 200成功  */
                HttpRequestUtils.toActive(IAndroidIdUtil.getAndroidId(getActivity()),activeCode.getText().toString(), new HttpRequestUtils.ActivationCallback() {
                    @Override
                    public void onSuccess(ActivationResponse result) {
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                // 处理成功的情况
                                int statusCode = result.getStatusCode();
                                String message = result.getMessage();
                                Log.e("mainHttp","toActive----onSuccess:"+result.toString());
                                if (statusCode == 200){
                                    canActive = true;
                                    HomeActivity.dateTime = message;
                                    RefreshDate();
                                }else {
                                    canActive = false;
                                    Toast.makeText(getActivity(), "" + message, Toast.LENGTH_SHORT).show();
                                    Log.e("mainHttp","toActive---message:"+message);
                                    ((HomeActivity)getActivity()).extracted() ;
                                }
                            }
                        });
                    }

                    @Override
                    public void onError(String error) {
                        // 处理失败的情况
                        Log.e("mainHttp","toActive---error:"+error);
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                canActive = false;
                                if (error.contains("connect")){
                                    Toast.makeText(getActivity(), "" +getString(R.string.conenct_erro), Toast.LENGTH_SHORT).show();
                                }else {
                                    Toast.makeText(getActivity(), "" + error, Toast.LENGTH_SHORT).show();
                                }
                                ((HomeActivity)getActivity()).extracted() ;
                            }
                        });
                    }
                });
            }
        }).start();

    }

    public void  RefreshDate(){
        try {
            if (canActive){
                activeDate.setText(getString(R.string.youxiaoqi)+HomeActivity.dateTime);
                activeDate.setTextColor(ContextCompat.getColor(getActivity(),R.color.mgreen));
                //activeCode.setText("");
                //activeCode.setVisibility(View.GONE);
                //activeButton.setVisibility(View.GONE);
            } else {
                activeDate.setText(getString(R.string.noActive));
                activeDate.setTextColor(ContextCompat.getColor(getActivity(),R.color.mred));
                //activeCode.setVisibility(View.VISIBLE);
                //activeButton.setVisibility(View.VISIBLE);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}