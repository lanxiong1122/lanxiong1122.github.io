package com.example.mycamera.util;

public class ActivationResponse {
    // toActive
    private int statusCode;
    private String message;
    //isActive
    private String homeUrl;
    private String expired;
    private boolean isActive;

    public String getHomeUrl() {
        return homeUrl;
    }

    public void setHomeUrl(String homeUrl) {
        this.homeUrl = homeUrl;
    }

    public String getExpired() {
        return expired;
    }

    public void setExpired(String expired) {
        this.expired = expired;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "ActivationResponse{" +
                "statusCode=" + statusCode +
                ", message='" + message + '\'' +
                ", homeUrl='" + homeUrl + '\'' +
                ", expired='" + expired + '\'' +
                ", isActive=" + isActive +
                '}';
    }
}
