package com.example.mycamera.util;

import android.content.Context;
import android.hardware.Camera;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;

import java.io.IOException;
import java.util.List;

// 打开预览相机
public class CameraHelper implements SurfaceHolder.Callback {

    private static final String TAG = "CustomCamera";

    private Camera mCamera;
    private SurfaceView mSurfaceView;
    private SurfaceHolder mSurfaceHolder;

    private int currentRotation;
    private boolean isFrontFacingCamera;

    public CameraHelper(Context context, SurfaceView surfaceView) {
        mSurfaceView = surfaceView;
        mSurfaceHolder = mSurfaceView.getHolder();
        mSurfaceHolder.addCallback(this);
        mSurfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        currentRotation = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRotation();
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Log.d(TAG, "surfaceCreated");
        openCameraAndSetPreview(holder);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        Log.d(TAG, "surfaceChanged - format: " + format + ", width: " + width + ", height: " + height);
        // Adjust camera parameters if needed based on the new dimensions
    }
/*
要实现替换相机预览数据，
你需要hook的方法是libcamera.so   _ZN7android6Camera25setPreviewCallbackWithBufferEPNS_14CameraListenerE
 Camera.setPreviewCallbackWithBuffer(Camera.PreviewCallback cb)。
这个方法允许你注册一个回调函数，当预览帧数据准备好时，
系统会调用该回调函数，
你可以在回调函数中处理这些预览帧数据。*/
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.d(TAG, "surfaceDestroyed");
        releaseCamera();
    }

    private void openCameraAndSetPreview(SurfaceHolder holder) {
        Log.d(TAG, "openCameraAndSetPreview");

        mCamera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);
        if (mCamera == null) {
            Log.e(TAG, "Failed to open camera.");
            return;
        }

        Camera.Parameters parameters = mCamera.getParameters();

        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        Camera.getCameraInfo(Camera.CameraInfo.CAMERA_FACING_FRONT, cameraInfo);
        isFrontFacingCamera = cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT;

        int rotation = calculateRotation(currentRotation, isFrontFacingCamera);
        Log.d(TAG, "Rotation calculated: " + rotation);

        parameters.setRotation(rotation);
        Log.d(TAG, "Setting camera parameters: " + parameters.flatten());

        List<Camera.Size> supportedPreviewSizes = parameters.getSupportedPreviewSizes();
        Camera.Size previewSize = determineBestPreviewSize(parameters, mSurfaceView.getWidth(), mSurfaceView.getHeight());
        if (previewSize != null) {
            parameters.setPreviewSize(previewSize.width, previewSize.height);
            Log.d(TAG, "Setting preview size: " + previewSize.width + "x" + previewSize.height);
        }
        // setPreviewCallbackWithBuffer结合addCallbackBuffer才会有回调
        //int bufferSize = parameters.getPreviewSize().width * parameters.getPreviewSize().height * ImageFormat.getBitsPerPixel(parameters.getPreviewFormat()) / 8;
        //mCamera.addCallbackBuffer(new byte[bufferSize]);
        mCamera.setPreviewCallback(new Camera.PreviewCallback() {
            @Override
            public void onPreviewFrame(byte[] data, Camera camera) {
                // 处理预览帧数据
                //mCamera.addCallbackBuffer(data);

                // 在这里对 data 进行处理，比如保存到文件、进行图像处理等
                //Log.d(TAG, "onPreviewFrame: frame received, data length = " + data.length);
            }
        });

        try {
            mCamera.setParameters(parameters);
            setCameraDisplayOrientation(mCamera); // 设置显示方向
            mCamera.setPreviewDisplay(holder);
            mCamera.startPreview();
            Log.d(TAG, "Camera preview started.");
        } catch (IOException e) {
            Log.e(TAG, "Failed to start camera preview.", e);
            releaseCamera();
        }
    }

    private void releaseCamera() {
        Log.d(TAG, "releaseCamera");
        if (mCamera!=null){
            mCamera.stopPreview();
            mCamera.setPreviewCallback(null);
            mCamera.release();
            mCamera = null;
            Log.d(TAG, "Camera released.");
        }
    }

    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        releaseCamera();
    }

    private int calculateRotation(int displayRotation, boolean frontFacing) {
        if (frontFacing) {
            switch (displayRotation) {
                case Surface.ROTATION_0:
                    return 270;
                case Surface.ROTATION_90:
                    return 180;
                case Surface.ROTATION_180:
                    return 90;
                case Surface.ROTATION_270:
                    return 0;
            }
        } else {
            switch (displayRotation) {
                case Surface.ROTATION_0:
                    return 90;
                case Surface.ROTATION_90:
                    return 0;
                case Surface.ROTATION_180:
                    return 270;
                case Surface.ROTATION_270:
                    return 180;
            }
        }
        return 0;
    }

    private void setCameraDisplayOrientation(Camera camera) {
        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(Camera.CameraInfo.CAMERA_FACING_FRONT, info);
        int rotation = ((WindowManager) mSurfaceView.getContext().getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRotation();
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0: degrees = 0; break;
            case Surface.ROTATION_90: degrees = 90; break;
            case Surface.ROTATION_180: degrees = 180; break;
            case Surface.ROTATION_270: degrees = 270; break;
        }

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % 360;
            result = (360 - result) % 360;  // compensate the mirror
        } else {  // back-facing
            result = (info.orientation - degrees + 360) % 360;
        }
        camera.setDisplayOrientation(result);
    }

    private Camera.Size determineBestPreviewSize(Camera.Parameters parameters, int surfaceWidth, int surfaceHeight) {
        List<Camera.Size> sizes = parameters.getSupportedPreviewSizes();
        if (sizes == null) return null;

        Camera.Size bestSize = null;
        int bestScore = Integer.MAX_VALUE;

        for (Camera.Size size : sizes) {
            int score = Math.abs(size.width - surfaceWidth) + Math.abs(size.height - surfaceHeight);
            if (score < bestScore) {
                bestScore = score;
                bestSize = size;
            }
        }
        return bestSize;
    }
}

