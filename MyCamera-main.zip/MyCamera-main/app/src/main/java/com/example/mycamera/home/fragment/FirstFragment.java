package com.example.mycamera.home.fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.cretin.tools.openwebview.OpenWebActivity;
import com.cretin.tools.openwebview.WebUtilsConfig;
import com.example.mycamera.R;
import com.example.mycamera.home.HomeActivity;


public class FirstFragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private View mFirst;
    public WebView webView;

    public FirstFragment() {
        // Required empty public constructor
    }

    public static FirstFragment newInstance(String param1, String param2) {
        FirstFragment fragment = new FirstFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        if (mFirst == null){
            mFirst = inflater.inflate(R.layout.fragment_first, container, false);
        }
        initFirstView();
        return mFirst;
    }
    private void initFirstView(){
        webView = mFirst.findViewById(R.id.first_web);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try {
                    Log.e("shouldOverrideUrlLoading","url-->"+url);
                    if (url.contains("file/download")){
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        view.getContext().startActivity(intent);
                    }else {
                        view.loadUrl(url);
                    }
                }catch (Exception exception){
                    exception.printStackTrace();
                }
                return true;
            }
        });
        //webView.loadUrl(HomeActivity.homeUrl);






//        WebUtilsConfig config =
//                new WebUtilsConfig()
//                        .setTitleBackgroundColor(R.color.teal_700)//设置标题栏背景色
//                        .setBackText("")//设置返回按钮的文案
//                        .setBackBtnRes(R.mipmap.arrow_left_white)//设置返回按钮的图标
//                        .setMoreBtnRes(R.mipmap.more_web)//设置更多按钮的图标
//                        .setShowBackText(true)//设置是否显示返回按钮的文案
//                        .setShowMoreBtn(false)//设置是否显示更多按钮
//                        .setShowTitleLine(true)//设置是否显示标题下面的分割线
//                        .setShowTitleView(true)//设置是否显示标题栏，网页是全屏的时候可以选择隐藏标题栏
//                        .setTitleBackgroundRes(-1)//设置标题栏背景资源
//                        .setBackTextColor(-1)//设置返回按钮的文案颜色
//                        .setTitleTextColor(-1)//设置标题文字颜色
//                        .setStateBarTextColorDark(false)//设置状态栏文字颜色是否是暗色，如果你设置了标题栏背景颜色为白色，这里需要设置true，否则状态栏看不到文案了
//                        .setTitleLineColor(R.color.app_title_color);//设置标题栏下面的分割线的颜色
//        OpenWebActivity.openWebView(getActivity(), HomeActivity.homeUrl, config);
    }
}