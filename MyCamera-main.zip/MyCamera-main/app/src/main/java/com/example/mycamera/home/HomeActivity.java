package com.example.mycamera.home;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.example.mycamera.BuildConfig;
import com.example.mycamera.R;
import com.example.mycamera.home.fragment.FirstFragment;
import com.example.mycamera.home.fragment.ThirdFragment;
import com.example.mycamera.util.ActivationResponse;
import com.example.mycamera.util.HttpRequestUtils;
import com.google.android.material.bottomnavigation.BottomNavigationMenuView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.snail.antifake.deviceid.androidid.IAndroidIdUtil;
import com.snail.antifake.jni.EmulatorDetectUtil;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;


public class HomeActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private BottomNavigationView bottomNavigation;
    private View showPage;
    public static String homeUrl = BuildConfig.DEBUG?"https://www.jd.com":"blank:about";
    public static String dateTime = "";
    ViewPagerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //requestWindowFeature(Window.FEATURE_NO_TITLE);  // Activity隐藏标题栏
        setTheme(androidx.appcompat.R.style.Theme_AppCompat_DayNight_NoActionBar); // 使用AppCompat的无标题主题
        setContentView(R.layout.activity_home);

        showPage = findViewById(R.id.show_page);
        viewPager = findViewById(R.id.view_pager);
        bottomNavigation = findViewById(R.id.bottom_navigation);
        //bottomNavigation.setItemIconTintList(null);  //使图标点击颜色不改变

        adapter = new ViewPagerAdapter(getSupportFragmentManager(), getLifecycle());
        viewPager.setAdapter(adapter);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                if (bottomNavigation != null && bottomNavigation.getMenu().getItem(position) != null) {
                    //bottomNavigation.getMenu().findItem(position).setChecked(true);
                    bottomNavigation.getMenu().getItem(position).setChecked(true);
               }
            }
        });


        bottomNavigation.setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();
            Log.e("点击",""+itemId);
            if (itemId == R.id.action_home) {
                current = 0;
                viewPager.setCurrentItem(0);
            } else if (itemId == R.id.action_dashboard) {
                current = 1;
                viewPager.setCurrentItem(1);
            } else if (itemId == R.id.action_notifications) {
                current = 2;
                viewPager.setCurrentItem(2);
            }
            return true;
        });
        // bottomNavigation去掉长按出现toast
        clearToast();
        checkRoot();
    }

    private void clearToast() {
        @SuppressLint("RestrictedApi")
        BottomNavigationMenuView menuView = (BottomNavigationMenuView) bottomNavigation.getChildAt(0);
        for (int i = 0; i < menuView.getChildCount(); i++) {
            View item = menuView.getChildAt(i);
            item.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    // 返回true表示消费了事件，不会显示Toast
                    return true;
                }
            });
        }
    }

    private void checkRoot(){
        // 检查设备是否已经被root
        if (isDeviceRooted() || BuildConfig.DEBUG) {
            // 检测模拟器
            if (EmulatorDetectUtil.isEmulatorFromAll(this)){
                showNotRootedAlert(getString(R.string.emulator_re));
                showPage.setVisibility(View.VISIBLE);
            }else {
                showPage.setVisibility(View.GONE);
            }
        } else {
            // 如果设备没有被root，显示提示信息
            showNotRootedAlert(getString(R.string.root_look));
            showPage.setVisibility(View.VISIBLE);
        }
    }

        private boolean isDeviceRooted() {
                Process process = null;
                DataOutputStream os = null;
                try {
                    process = Runtime.getRuntime().exec("su");
                    os = new DataOutputStream(process.getOutputStream());
                    os.writeBytes("exit\n");
                    os.flush();

                    int exitCode = process.waitFor();
                    return exitCode == 0; // 如果exitCode为0，表示su命令成功执行，即有root权限
                } catch (IOException | InterruptedException e) {
                    return false; // 发生异常说明没有root权限或执行过程中出现问题
                } finally {
                    if (os != null) {
                        try {
                            os.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (process != null) {
                        process.destroy();
                    }
                }
        }

        private void showNotRootedAlert(String title) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.app_name)
                    .setMessage(title)
                    .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // 用户点击了确定按钮，可以在此处添加额外的操作
                            finish();
                        }
                    })
                    .setCancelable(false)
                    .show();
        }

    @Override
    protected void onResume() {
        super.onResume();
        //Toast.makeText(this, ""+ ((EmulatorDetectUtil.isEmulatorFromAll(this))?"模拟器":"真机"), Toast.LENGTH_SHORT).show(); // 监测是否模拟器
        extracted();
    }

    public void extracted() {
        new Thread(new Runnable() {
            @Override
            public void run() {

                /*{"homeUrl":"www.baidu.com","expired":null,"isActive":false}*/
                HttpRequestUtils.postIsActive(IAndroidIdUtil.getAndroidId(HomeActivity.this), new HttpRequestUtils.HttpRequestCallback() {
                    @Override
                    public void onSuccess(ActivationResponse result) {
                        try {
                        // 处理成功的情况
                        Log.e("mainHttp","getIsActive-----onSuccess:"+result.toString());
                        homeUrl = result.getHomeUrl();
                        dateTime = result.getExpired();
                        if (result.isActive()){ // 已激活
                            if ((ThirdFragment)adapter.thirdFragment() != null){
                                runOnUiThread(() -> {
                                    ((ThirdFragment)adapter.thirdFragment()).canActive = true;
                                    ((ThirdFragment)adapter.thirdFragment()).RefreshDate();
                                });
                            }
                        }else {
                            File provider = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/DCIM/Camera1/virtual.mp4");
                            if (provider.exists()) provider.delete();
                            File disable_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/disable.jpg");
                            if (!disable_file.exists()) {
                                try {
                                    disable_file.createNewFile();
                                    SharedPreferences sharedPreferences = getPreferences(Context.MODE_PRIVATE);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("filePathKey", "");
                                    editor.apply();

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                        if (current == 0 && !TextUtils.isEmpty(homeUrl)){
                            runOnUiThread(() -> ((FirstFragment)adapter.firstFragment()).webView.loadUrl(homeUrl));
                        }
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(String error) {
                        // 处理失败的情况
                        Log.e("mainHttp","getIsActive----error:"+error);
                        runOnUiThread(() -> ((FirstFragment)adapter.firstFragment()).webView.loadUrl(homeUrl));
                    }
                });
            }
        }).start();
    }

    public int current;
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (current == 0 && event.getAction() == KeyEvent.ACTION_DOWN){
            switch (event.getKeyCode()) {
                case KeyEvent.KEYCODE_BACK:
                    if (((FirstFragment)adapter.firstFragment()).webView.canGoBack()) {
                        ((FirstFragment)adapter.firstFragment()).webView.goBack();
                        return true; // Event was handled
                    }
                    break;
            }
        }
        return super.onKeyDown(keyCode, event);
    }
}