package com.example.mycamera.dealvideo;

public interface InitListener {
    public void onLoadSuccess();
    public void onLoadFail(String reason);
}
