package com.example.mycamera.home.fragment;

import static androidx.core.content.ContextCompat.checkSelfPermission;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.fragment.app.Fragment;

import com.example.mycamera.R;
import com.example.mycamera.util.CameraHelper;

public class SecondFragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private FrameLayout mLayout;
    private SurfaceView mSurfaceView;
    private CameraHelper mCameraHelper;
    private View mSecondView;

    public SecondFragment() {
        // Required empty public constructor
    }

    public static SecondFragment newInstance(String param1, String param2) {
        SecondFragment fragment = new SecondFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        if (mSecondView == null){
            mSecondView = inflater.inflate(R.layout.fragment_second, container, false);
        }
        initSecond();
        return mSecondView;
    }

    private void initSecond() {
        mLayout =  mSecondView.findViewById(R.id.surfaceTwo);
        mSecondView.findViewById(R.id.preview_center).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getActivity().checkSelfPermission(Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, 100);
                    return;
                }
                try{
                // 每次重启释放
                if (mCameraHelper != null){
                    return;
                }
                if (mSurfaceView == null) mSurfaceView = new SurfaceView(getActivity());
                mSurfaceView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
                if (mSurfaceView.getParent() != null && mSurfaceView.getParent() instanceof ViewGroup) {
                    ((ViewGroup) mSurfaceView.getParent()).removeView(mSurfaceView);
                }
                mLayout.addView(mSurfaceView);
                mCameraHelper = new CameraHelper(getContext(),mSurfaceView);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        mSecondView.findViewById(R.id.stop_center).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (mCameraHelper != null){
                        mCameraHelper.onDestroy();
                        mCameraHelper = null;
                    }
                    mLayout.removeView(mSurfaceView);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }
}