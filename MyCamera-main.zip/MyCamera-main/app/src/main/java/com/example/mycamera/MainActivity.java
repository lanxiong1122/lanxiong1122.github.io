package com.example.mycamera;


import static com.example.mycamera.FileUtil.createMyFile;
import static com.example.mycamera.FileUtil.currentOutputVideoPath;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mycamera.dealvideo.CompressListener;
import com.example.mycamera.dealvideo.Compressor;
import com.example.mycamera.dealvideo.CustomProgressDialog;
import com.example.mycamera.dealvideo.GetPathFromUri;
import com.example.mycamera.dealvideo.InitListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private String TAG = this.getClass().getName();

    private Switch disable_switch;               // 替换以及还原
    private Switch disable_toast_switch;         // 关闭提示
    private TextView click_video_view,show_pre_log;           // 选择视频
    private int PICK_VIDEO_REQUEST = 10086;      //选择视频
    private Spinner spin_corner;                 //角度
    private Spinner spin_resolution;             //分辨率

    private Compressor mCompressor;
    private String videoTime = "";               //获取视频时长
    private int videoWidth = 0;                  //获取视频的宽度
    private int videoHeight = 0;                 //获取视频的高度
    private int videoDirection = 0;               //获取视频的角度
    private Double videoLength = 0.00;           //视频时长 s
    private CustomProgressDialog mProcessingDialog;
    private String mVideoPath = "";              //原视频地址
    private String videoCorner;                  //视频角度
    private String videoResolution;              //视频分辨率

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_DENIED) {
                Toast.makeText(MainActivity.this, R.string.permission_lack_warn, Toast.LENGTH_SHORT).show();
            }else {
                File camera_dir = new File (Environment.getExternalStorageDirectory().getAbsolutePath()+"/DCIM/Camera1/");
                if (!camera_dir.exists()){
                    camera_dir.mkdir();
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        sync_statue_with_files();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        disable_switch = findViewById(R.id.switch2);
        disable_toast_switch = findViewById(R.id.switch5);
        click_video_view = findViewById(R.id.click_video_view);
        spin_corner = findViewById(R.id.spin_corner);
        spin_resolution = findViewById(R.id.spin_resolution);
        show_pre_log = findViewById(R.id.show_pre_log);



        sync_statue_with_files();
        currentOutputVideoPath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/DCIM/Camera1/virtual.mp4";
        // 替换以及还原
        disable_switch.setOnCheckedChangeListener((compoundButton, b) -> {
            Toast.makeText(this, "重启目标应用生效", Toast.LENGTH_SHORT).show();
            if (compoundButton.isPressed()) {
                if (!has_permission()) {
                    request_permission();
                } else {
                    File disable_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/disable.jpg");
                    if (disable_file.exists() != b){
                        if (b){
                            try {
                                disable_file.createNewFile();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }else {
                            disable_file.delete();
                        }
                    }
                }
                sync_statue_with_files();
            }
        });
        // 消息提示
        disable_toast_switch.setOnCheckedChangeListener((compoundButton, b) -> {
            if (compoundButton.isPressed()) {
                if (!has_permission()) {
                    request_permission();
                } else {
                    File disable_toast_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/no_toast.jpg");
                    if (disable_toast_file.exists() != b){
                        if (b){
                            try {
                                disable_toast_file.createNewFile();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }else {
                            disable_toast_file.delete();
                        }
                    }
                }
                sync_statue_with_files();
            }
        });
        // 选择视频
        click_video_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("video/*"); // 设置类型为视频
                startActivityForResult(intent, PICK_VIDEO_REQUEST);
            }
        });
         // 旋转角度
        ArrayAdapter<CharSequence> adapterCorner = ArrayAdapter.createFromResource(this, R.array.corner, android.R.layout.simple_spinner_item);
        adapterCorner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_corner.setAdapter(adapterCorner);
        spin_corner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        videoCorner = parent.getItemAtPosition(position).toString();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                        // 不做处理
                    }
                });
        // 选择分辨率
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.resolution, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_resolution.setAdapter(adapter);
        spin_resolution.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                videoResolution = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // 不做处理
            }
        });
        // 处理视频
        findViewById(R.id.deal_video).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startCompress();
            }
        });
        // 去预览
        findViewById(R.id.pre_video).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,VideoPreview.class));
            }
        });
        initVideo();
    }

    private void request_permission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (this.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
                    || this.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle(R.string.permission_lack_warn);
                builder.setMessage(R.string.permission_description);

                builder.setNegativeButton(R.string.negative, (dialogInterface, i) -> Toast.makeText(MainActivity.this, R.string.permission_lack_warn, Toast.LENGTH_SHORT).show());

                builder.setPositiveButton(R.string.positive, (dialogInterface, i) -> requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1));
                builder.show();
            }
        }
    }

    private boolean has_permission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return this.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_DENIED
                    && this.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_DENIED;
        }
        return true;
    }


    private void sync_statue_with_files() {

        TextView ourId = findViewById(R.id.ourId);
        try {
            ourId.setText(getResources().getString(R.string.androidid)+ Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
        Log.d(this.getApplication().getPackageName(), "【MyCamera】[sync]同步开关状态");

        if (!has_permission()){
            request_permission();
        }else {
            File camera_dir = new File (Environment.getExternalStorageDirectory().getAbsolutePath()+"/DCIM/Camera1");
            if (!camera_dir.exists()){
                camera_dir.mkdir();
            }
        }
         }catch (Exception e){
            e.printStackTrace();
        }
        // 1关闭加载模块功能即还原相机
        File disable_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/disable.jpg");
        disable_switch.setChecked(disable_file.exists());

        // 2显示权限缺失应用，例如读写
        File force_show_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/force_show.jpg");
        createMyFile(force_show_file);

        // 3视频有声音
        File play_sound_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/no-silent.jpg");
        createMyFile(play_sound_file);

        // 4强制视频在相机目录下
        File force_private_dir_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/private_dir.jpg");
        createMyFile(force_private_dir_file);

        // 关闭提示消息
        File disable_toast_file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/DCIM/Camera1/no_toast.jpg");
        disable_toast_switch.setChecked(disable_toast_file.exists());

        try{
            // 获取SharedPreferences实例
            SharedPreferences sharedPreferences = getPreferences(Context.MODE_PRIVATE);
            File showFile = new File("/storage/emulated/0/DCIM/Camera1/virtual.mp4");
            click_video_view.setText("当前选择视频路径："+(showFile.exists() ? sharedPreferences.getString("filePathKey", "空") : "空"));
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            // 将其写入预览视频，后面修改角度及分辨率等会进行替换
            new Thread(new Runnable() {
                @Override
                public void run() {
                    FileUtil.copyVideoToDestination(MainActivity.this, data.getData(), "/storage/emulated/0/DCIM/Camera1/virtual.mp4");
                }
            }).start();
            // 获取真实路径，将其展示出来
            mVideoPath = GetPathFromUri.getPath(MainActivity.this, data.getData());
            Log.i(TAG, "Select file: " + mVideoPath);
            click_video_view.setText("" + mVideoPath);
            // 打印视频信息
            getVideoTime(mVideoPath);
            // 把路径存储
            SharedPreferences sharedPreferences = getPreferences(Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("filePathKey", mVideoPath);
            editor.apply();
        }
    }

    /**
     * 获取视频的时长
     */
    void getVideoTime(String videoPath) {
        try {
            MediaMetadataRetriever retr = new MediaMetadataRetriever();
            retr.setDataSource(videoPath);
            videoTime = retr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);//获取视频时长
            videoWidth = Integer.parseInt(retr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));//获取视频的宽度
            videoHeight = Integer.parseInt(retr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));//获取视频的高度
            videoDirection = Integer.parseInt(retr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));//获取视频的角度

            Log.e(TAG, "videoTime=" + videoTime);
            Log.e(TAG, "videoWidth=" + videoWidth);
            Log.e(TAG, "videoHeight=" + videoHeight);
            Log.e(TAG, "videoDirection=" + videoDirection);

//            MyLog.i(TAG, "videoTime=" + videoTime);
//            mBitMap = retr.getFrameAtTime();
            videoLength = Double.parseDouble(videoTime) / 1000.00;
            Log.e(TAG, "videoLength=" + videoLength);
            show_pre_log.setText("success " +
                    "videoTime=" + videoTime+"毫秒\n" +
                    "videoWidth=" + videoWidth+"\n"+
                    "videoHeight=" + videoHeight+"\n"+
                    "videoDirection=" + videoDirection+"\n"+
                    "videoLength=" + videoLength+"秒\n");
        } catch (Exception e) {
            e.printStackTrace();
            Log.i(TAG, "e=" + e.getMessage());
            videoLength = 0.00;
            Toast.makeText(MainActivity.this, "异常错误", Toast.LENGTH_SHORT);
        }

    }


    private void initVideo() {
        mProcessingDialog = new CustomProgressDialog(this);
        mProcessingDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                Log.i(TAG, "onDismiss");//如果取消压缩，那么需要销毁
                if (mCompressor != null) {
                    mCompressor.destory();
                }
            }
        });

        mCompressor = new Compressor(this);
        mCompressor.loadBinary(new InitListener() {
            @Override
            public void onLoadSuccess() {
                Log.v(TAG, "load library succeed");
            }

            @Override
            public void onLoadFail(String reason) {
                Log.i(TAG, "load library fail:" + reason);
            }
        });
    }


    /**
     * 处理视频
     */
    private void startCompress() {
        try {
            if (TextUtils.isEmpty(mVideoPath) || (videoResolution.equals("默认原始分辨率") && videoCorner.equals("默认原始角度"))) {
                Toast.makeText(this, TextUtils.isEmpty(mVideoPath)?"请重新选择视频":"未选择角度或分辨率不用处理", Toast.LENGTH_SHORT).show();
            } else {
                File file = new File(currentOutputVideoPath);
                if (file.exists()) {
                    file.delete();
                }
                String cmd = "";
                Log.i(TAG, "startCompress=mVideoPath=" + mVideoPath);

                    if ("默认原始分辨率".equals(videoResolution)) videoResolution = videoWidth + "x" + videoHeight;
                    Log.e(TAG,"分辨率: " + videoResolution);
                    // 根据旋转角度设置transpose滤镜
                    String transposeFilter = "";
                    switch (videoCorner){
                        case "顺时针90度":
                            transposeFilter = "transpose=1";
                            break;
                        case "逆时针90度":
                            transposeFilter = "transpose=2";
                            break;
                        default:
                            transposeFilter = "";
                            break;
                    }
                    Log.e(TAG,"旋转角度: " + videoCorner);
                     // 构建FFmpeg命令
                    cmd = "-y -i " + mVideoPath + " -strict -2"
                            + (transposeFilter.isEmpty() ? "" : " -vf "+transposeFilter)+ " -vcodec libx264 -preset ultrafast "
                            + "-crf 24 -acodec aac -ar 44100 -ac 2 -b:a 96k -s " + videoResolution
                            /*+ (aspectRatioStr.isEmpty() ? "" : " -aspect " + aspectRatioStr)*/   // 视频宽高比，暂时不需要，不设根据原始视频
                            + " " + currentOutputVideoPath;
                 // 成功示例，空格问题导致执行不成功
                /*cmd = "-y -i " + mVideoPath + " -strict -2 -vf transpose=3 -vcodec libx264 -preset ultrafast " +
                        "-crf 24 -acodec aac -ar 44100 -ac 2 -b:a 96k -s 1080x1920 -aspect 9:16 " + currentOutputVideoPath;*/
                Log.e(TAG,"Generated FFmpeg command: " + cmd);
                mProcessingDialog.show();
                mProcessingDialog.setProgress(0);
                execCommand(cmd);
            }
        } catch (Exception e) {
            Log.e(TAG, "startCompress=e=" + e.getMessage());
        }

    }

    private void execCommand(final String cmd) {
        File mFile = new File(currentOutputVideoPath);
        if (mFile.exists()) {
            mFile.delete();
        }
        Log.i(TAG, "cmd= " + cmd);
        mCompressor.execCommand(cmd, new CompressListener() {
            @Override
            public void onExecSuccess(String message) {
                mProcessingDialog.dismiss();
                String result = getString(R.string.compress_result_input_output, mVideoPath
                        , getFileSize(mVideoPath), currentOutputVideoPath, getFileSize(currentOutputVideoPath));
                Log.i(TAG, "success " + result);
                getVideoTime(currentOutputVideoPath);
                //Toast.makeText(MainActivity.this, "success " + result, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onExecFail(String reason) {
                Log.i(TAG, "fail " + reason);
                show_pre_log.setText("fail " + reason);
                //Toast.makeText(MainActivity.this, "压缩失败", Toast.LENGTH_SHORT);
                mProcessingDialog.dismiss();
            }

            @Override
            public void onExecProgress(String message) {
                try {
                    Log.i(TAG, "progress " + message);
                    show_pre_log.setText("progress " + message);
                    double switchNum = getProgress(message);
                    if (switchNum == 10000) {
                        //如果找不到压缩的片段，返回为10000
                        Log.i(TAG, "10000");
                        mProcessingDialog.setProgress(0);
                    } else {
                        mProcessingDialog.setProgress((int) (getProgress(message) / 10));
                    }
                } catch (Exception e) {
                    mProcessingDialog.dismiss();
                    Log.i(TAG, "e=" + e.getMessage());
                }
            }
        });
    }

    // 进度条，只能是整形，所以max为1000，最少为0
    double getProgressNum = 0.0;

    private double getProgress(String source) {
        if (source.contains("too large")) {//当文件过大的时候，会会出现 Past duration x.y too large
            Log.i(TAG, "too large");
            return getProgressNum;
        }
        Pattern p = Pattern.compile("00:\\d{2}:\\d{2}");
        Matcher m = p.matcher(source);
        if (m.find()) {
            //00:00:00
            String result = m.group(0);
            String temp[] = result.split(":");
            double seconds = Double.parseDouble(temp[1]) * 60 + Double.parseDouble(temp[2]);
            if (0 != videoLength) {
                getProgressNum = seconds / videoLength * 1000;
                return seconds / videoLength * 1000;
            }
            if (seconds == videoLength) {
                return 1000;
            }
        }
//        MyLog.i(TAG, "!m.find()="+getProgressNum);
        return 10000;//出现异常的时候，返回为10000
//      return 0;//出现异常的时候，显示上一个进度条
    }

    private String getFileSize(String path) {
        File f = new File(path);
        if (!f.exists()) {
            return "0 MB";
        } else {
            long size = f.length();
            return (size / 1024f) / 1024f + "MB";
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mCompressor != null) {
            mCompressor.destory();
        }
    }

}



