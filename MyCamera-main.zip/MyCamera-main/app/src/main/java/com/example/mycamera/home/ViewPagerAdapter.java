package com.example.mycamera.home;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.mycamera.home.fragment.FirstFragment;
import com.example.mycamera.home.fragment.SecondFragment;
import com.example.mycamera.home.fragment.ThirdFragment;

public class ViewPagerAdapter extends FragmentStateAdapter {

    public ViewPagerAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 1:
                return new SecondFragment();
            case 2:
                ThirdFragment thirdFragment = new ThirdFragment();
                third = thirdFragment;
                return thirdFragment;
            default:
                FirstFragment firstFragment = new FirstFragment();
                first = firstFragment;
                return firstFragment;
        }
    }
    private FirstFragment first;
    public FirstFragment firstFragment(){
        return first;
    }

    private ThirdFragment third;
    public ThirdFragment thirdFragment(){
        return third;
    }
    @Override
    public int getItemCount() {
        return 3; // 根据你的需求更改页面数量
    }
}
